/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: imaaitat <imaaitat@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/14 01:21:11 by imaaitat          #+#    #+#             */
/*   Updated: 2023/06/04 01:37:55 by imaaitat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putstr_fd(char	*s, int fd)
{
	if (!s)
		return ;
	if (s[0] == '-' && s[1] == '/' && s[2] == ',')
		write(2, "cd: error retrieving current\
directory: getcwd: cannot access\
parent directories: No such file or directory \n", 108);
	else
		write(fd, s, ft_strlen(s));
}
