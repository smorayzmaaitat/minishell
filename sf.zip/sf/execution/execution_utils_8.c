/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execution_utils_8.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: imaaitat <imaaitat@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/23 16:52:39 by imaaitat          #+#    #+#             */
/*   Updated: 2023/06/06 00:30:42 by imaaitat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"
#include <unistd.h>

void	wait_for_all(t_env **head)
{
	while ((waitpid(-1, &g_status, 0)) != -1)
	{
		if (WIFSIGNALED(g_status) && access("/tmp/h_c", X_OK) != 0)
		{
			g_status = WTERMSIG(g_status);
			if (g_status == SIGINT)
			{
				if (g_status == SIGINT)
					write(2, "\n", 1);
				set_delete("?", ft_itoa(130), head);
			}
			else if (g_status == SIGQUIT)
			{
				if (g_status == SIGQUIT)
					write(2, "Quit: 3\n", 8);
				set_delete("?", ft_itoa(131), head);
			}
		}
		else
		{
			g_status = WEXITSTATUS(g_status);
			set_delete("?", ft_itoa(g_status), head);
		}
	}
}

void	wait_for_specific(int pid, t_env **head)
{
	waitpid(pid, &g_status, 0);
	if (WIFSIGNALED(g_status))
	{
		g_status = WEXITSTATUS(g_status);
		g_status = WTERMSIG(g_status);
		set_delete("?", ft_itoa(g_status), head);
		if (g_status == SIGINT)
			set_delete("?", ft_itoa(130), head);
		else if (g_status == SIGQUIT)
			set_delete("?", ft_itoa(131), head);
		printf("Quit: %d\n", g_status);
	}
}

void	free_pipes(t_exe_fd *exe_fd, t_cmd *p)
{
	int	j;

	j = -1;
	if (p->next != NULL)
	{
		while (++j <= p->next->fd_in)
			free(exe_fd->pipe[j]);
		free(exe_fd->pipe);
	}
	else
	{
		while (++j <= p->fd_in)
			free(exe_fd->pipe[j]);
		free(exe_fd->pipe);
	}
}

void	close_all(t_exe_fd *exe_fd, t_cmd *p, int i)
{
	int	j;

	j = -1;
	close(exe_fd->out);
	close(exe_fd->fd_heredoc);
	close(exe_fd->infile);
	close(exe_fd->outfile);
	if (p->next != NULL)
	{
		while (++j <= p->next->fd_in)
			close(exe_fd->pipe[j][1]);
		j = -1;
		while (++j <= p->next->fd_in)
			close(exe_fd->pipe[j][0]);
	}
	else
	{
		while (++j <= p->fd_in)
			close(exe_fd->pipe[j][1]);
		j = -1;
		while (++j <= p->fd_in)
			close(exe_fd->pipe[j][0]);
	}
	if (i)
		free_pipes(exe_fd, p);
}

void	create_pipes(t_exe_fd *exe_fd, t_cmd **p_cmd)
{
	t_cmd	*tmp;
	int		i;
	int		j;

	i = 0;
	j = 0;
	exe_fd->out = dup(1);
	exe_fd->in = dup(0);
	tmp = *p_cmd;
	tmp->fd_in = -1;
	while (tmp)
	{
		if (tmp->next)
			i++;
		tmp = tmp->next;
	}
	exe_fd->pipe = (int **)malloc(sizeof(int *) * (i));
	while (j < i)
	{
		exe_fd->pipe[j] = (int *)malloc(sizeof(int) * 2);
		j++;
	}
}
