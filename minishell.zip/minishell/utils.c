#include "./includes/minishell.h"
#include "libft/libft.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/fcntl.h>
#include <sys/unistd.h>
#include <time.h>
#include <unistd.h>
#include <readline/readline.h>
#include <unistd.h>


void execution(char *command,char **args) {
  char *path;
  char **dir;
  int i;
  i = 0;
    if (ft_strchr(command, '/'))
      path = command;
    else {
      dir = ft_split(getenv("PATH"), ':');
      while (dir[i]) {
        path = ft_strjoin(dir[i], "/");
        path = ft_strjoin(path, command);
        if (access(path, X_OK) == 0)
          break;
        i++;
      }
    }

    if (execve(path, args, NULL) == -1) {
     perror("execve");
      exit(1);
    }
  }

// void ft_pipe(char *command1,char **args1, char *command2,char **args2,t_cmd *p_cmd) {
//   int fd[2];
//   int pid;
//   int status;
//   pipe(fd);
//   pid = fork();
//   if (pid == 0){
//     close(fd[0]);
//     dup2(fd[1],1);
//     close(fd[1]);
//     execution(command1,args1);
//   } else {
//     close(fd[1]);
//     dup2(fd[0],0);
//     close(fd[0]);
//     waitpid(pid, &status, 0);
//     if(p_cmd->status == 1)
//       ft_pipe(command2,args2, p_cmd->next->command,p_cmd->next->args,p_cmd->next);
//     else
//     execution(command2,args2);
//   }
// }

int ft_exit() {
printf("exit");
    exit(0);
}

int builtin_cmd(char *command, char **args) {
  if (ft_strcmp(command, "cd") == 0) {
    ft_cd(args[1]);
    return 1;
  }
  if (ft_strcmp(command, "pwd") == 0) {
    ft_pwd(1);
    return 1;
  }
  if (ft_strcmp(command, "echo") == 0) {
    ft_echo(args);
    return 1;
  }
  if (ft_strcmp(command, "exit") == 0) {
    ft_exit();
    return 1;
  }
  return 0;
}



int get_len(char **args) {
  int i;

  i = 0;
  while (args[i])
    i++;
  return i;
}

int check_heredoc(char **del)
{
  int count;
  char *input;
  int fd;
  int i;

  i =0;
  input = readline("heredoc>");
  fd = open("...", O_RDWR | O_CREAT | O_APPEND, 0777);
  
  count = get_len(del);
  if (count == 1)
  {
  while(ft_strcmp(input, del[count-1]) != 0)
  {
    if(ft_strcmp(input, del[count-1]) != 0)
        ft_putendl_fd(input, fd);
      input = readline("heredoc>");
  }
  }
  else
  {
    while(i < count - 1)
    {
      if(ft_strcmp(input, del[i]) == 0)
        i++;
      input = readline("heredoc>");
    }

    while(ft_strcmp(input, del[count-1]) != 0)
    {
      if(ft_strcmp(input, del[count-1]) != 0)
        ft_putendl_fd(input, fd);
      input = readline("heredoc>");
    }
  }
  close(fd);
  fd = open("...", O_RDONLY);
  unlink("...");
  free(input);
  dup2(fd, 0);
  return fd;
}

int create_in_files(t_cmd *p_cmd)
{
  int i;
  int fd;

  i = 0;
  fd = 0;
  while(p_cmd->infile[i])
  {
  if (access(p_cmd->infile[i], F_OK) == 0)
  {
   fd = open(p_cmd->infile[i], O_RDWR );
    if (fd == -1)
    {
      perror("open");
      return 0;
    }
  }
  else {
  printf("%s No such file or directory\n", p_cmd->infile[i]);
  exit(1);
  }
  if (p_cmd->infile[i + 1] != NULL)
      close(fd);
  i++;}
  return (fd);
}

int create_out_files(t_cmd *p_cmd)
{
  int i;
  int fd;

  i = 0;
  fd = 0;
  while(p_cmd->outfile[i])
  {
  if(p_cmd->is_red_or_app == 0)
   fd = open(p_cmd->outfile[i], O_RDWR | O_CREAT | O_TRUNC, 0644);
  else
    fd = open(p_cmd->outfile[i], O_RDWR | O_CREAT | O_APPEND, 0644);
  if (fd == -1)
    {
      perror("open");
      return 0;
    }
    if (p_cmd->outfile[i + 1] != NULL)
      close(fd);
    i++;
  }
  return (fd);
}

int ft_pwd(int fd) {
  char *pwd;

  pwd = getcwd(NULL, 0);
  ft_putstr_fd(pwd, fd);
  ft_putstr_fd("\n", fd);
  free(pwd);
  return 1;
}


int ft_create_file(char *argv) {
  int fd;

  fd = open(argv, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fd == -1) {
    perror("open");
    return 0;
  }
  return fd;
}

int ft_close_file(int fd) {
  if (close(fd) == -1) {
    perror("close");
    return 0;
  }
  return 1;
}

int chek_args(char **argv) {
  int i;

  i = 1;
  while (argv[i]) {
    if (ft_strcmp(argv[i], "-n") == 0)
      return 1;
    i++;
  }
  return 0;
}

int ft_echo(char **argv) {
  int i;

  i = 1;
  while (argv[i]) {
    if (ft_strcmp(argv[i], "-n") == 0)
      i++;
    ft_putstr_fd(argv[i], 1);
    i++;
  }
  if (chek_args(argv) == 0)
    ft_putstr_fd("\n", 1);
  return 1;
}

int ft_redirection(char **command, char *name_file) {
  int fd;

  fd = ft_create_file(name_file);
  if (fd == 0)
    return 0;
  ft_echo(command);
  ft_close_file(fd);
  return 1;
}

int ft_append(char **command, char *name_file) {
  int fd;

  fd = open(name_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
  if (fd == -1) {
    perror("open");
    return 0;
  }
  ft_echo(command);
  ft_close_file(fd);
  return 1;
}

void ft_cd(char *argv) {
  if (chdir(argv) != 0) {
    perror("cd");
    return;
  }
}