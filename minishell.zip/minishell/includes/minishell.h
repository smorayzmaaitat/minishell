#include <stdlib.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include "../libft/libft.h"


typedef struct l_cmd
{
    char            *command;
    char            **args;
    int             is_red_or_app;
    int             fd_in;
    char            **infile;
    int             status;
    char            **outfile;
    char            **heredoc_del;
    struct l_cmd    *next;
}            t_cmd;

void execution(char *command,char **args);
int check_heredoc(char **del);
void    ft_cd(char *argv);
int ft_pwd(int fd);
int create_out_files(t_cmd *p_cmd);
int builtin_cmd(char *command, char **args);
int create_in_files(t_cmd *p_cmd);
void ft_pipe(char *command1,char **args1, char *command2,char **args2,t_cmd *p_cmd);
int ft_echo(char **argv);
int ft_redirection(char **command, char *name_file);
char *ft_export(char *argv);