#include <stdio.h>
#include <fcntl.h>
#include "../libft/libft.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/fcntl.h>
#include <sys/unistd.h>
#include <time.h>
#include <readline/readline.h>
#include <unistd.h>

typedef struct s_env
{
    char            *name;
    char            *value;
    struct s_env    *next;
}            t_env;

typedef struct l_cmd
{
    char            *command;
    char            **args;
    int             is_red_or_app;
    int             fd_in;
    char            **infile;
    char            **outfile;
    char            **heredoc_del;
    struct l_cmd    *next;
}            t_cmd;

void execution(char *command,char **args);
int check_heredoc(char **del);
void    ft_cd(char *argv);
int ft_pwd(int fd);
void signal_handler(int signum);
int create_out_files(t_cmd *p_cmd);
int builtin_cmd(char *command, char **args,t_env *head);
int create_in_files(t_cmd *p_cmd);
void ft_pipe(char *command1,char **args1, char *command2,char **args2,t_cmd *p_cmd);
int ft_echo(char **argv);
int ft_redirection(char **command, char *name_file);
char *ft_export(char *argv);
void print_env(t_env *env,int i);
void free_env(t_env *env);
t_env *sort_env(t_env **head);
t_env *set_env(char **env, t_env *head);
t_env *copy_env(t_env *head);
int chek_plus(char *str);
void serch_replace(t_env *head,char *name,char *value);
char *get_name(char *str);
char *get_value(char *str);