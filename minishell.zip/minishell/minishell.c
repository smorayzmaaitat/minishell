#include "./includes/minishell.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/_types/_pid_t.h>
#include <sys/_types/_u_char.h>
#include <sys/fcntl.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/unistd.h>
#include <sys/wait.h>
#include <unistd.h>
t_cmd *listnew(char *command, char **args) {
  t_cmd *new;
  new = malloc(sizeof(t_cmd));
  new->command = command;
  new->args = args;
  new->outfile = NULL;
  new->infile = NULL;
  return new;
}
int status;
int main(int ac, char **av, char **env) {
  (void)(ac);
  (void)(av);
  struct l_cmd *p_cmd ;
    p_cmd = listnew("env", NULL);
    p_cmd->args = malloc(sizeof(char *) * 3);
    p_cmd->args[0] = "l=s";
    p_cmd->args[1] = "t=l";
    p_cmd->args[2] = NULL;


  int fd[2];
  int fd_in = 0;
  int fd_out = 1;
  int out = dup(1);
  int in = dup(0);
  t_env *head;
  t_env *headd;
  head = NULL;
  headd = set_env(env, head);
  while (p_cmd != NULL) {
    //bach nrj3 yktb l output f terminal
    dup2(out, 1);
    dup2(in, 0);
    if(p_cmd->heredoc_del)
      check_heredoc(p_cmd->heredoc_del);

    else if (p_cmd->infile) {
      fd_in = create_in_files(p_cmd);
      dup2(fd_in, 0);
      close(fd_in);
    }
    if (p_cmd->outfile) {
      fd_out = create_out_files(p_cmd);
      dup2(fd_out, 1);
      //bach cat tkhrj 3la l terminal
      dup2(fd_out, 0);
      close(fd_out);
      p_cmd->next->fd_in = 1;
    }
    if ( p_cmd->next != NULL && p_cmd->outfile == NULL)
    {
      pipe(fd);
      dup2(fd[1],1);
      close(fd[1]);
       p_cmd->next->fd_in = 1;
    }
    int pid = fork();
    if (pid == 0) {
      if (p_cmd->fd_in != 0){
        dup2(fd[0],0);
        close(fd[0]);
      }
      if(builtin_cmd(p_cmd->command, p_cmd->args, headd))
        exit(0);
      else
      execution(p_cmd->command, p_cmd->args);
    }
     waitpid(pid, &status, 0);
     printf("status = %d\n", status);
    p_cmd = p_cmd->next;
  }
}
