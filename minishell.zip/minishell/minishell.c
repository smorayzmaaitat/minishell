#include "./includes/minishell.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/_types/_pid_t.h>
#include <sys/_types/_u_char.h>
#include <sys/fcntl.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/unistd.h>
#include <sys/wait.h>
#include <unistd.h>
t_cmd *listnew(char *command, char **args, int status) {
  t_cmd *new;
  new = malloc(sizeof(t_cmd));
  new->command = command;
  new->args = args;
  new->status = status;
  new->outfile = NULL;
  new->infile = NULL;
  return new;
}
int status;
int main(int ac, char **av) {
  (void)(ac);
  (void)(av);
  struct l_cmd *p_cmd;
  char **args = malloc(sizeof(char *) *1);
  args[0] = "cat";
  args[1] = NULL;
  char **args2 = malloc(sizeof(char *) * 2);
  args2[0] = "echo";
  args2[1] = malloc(sizeof(char) * 2);
  args2[1] = "#";
  args2[2] = NULL;
 char **args3 = malloc(sizeof(char *) * 1);
  args3[0] = "cat";
  args3[1] = NULL;
  char **args4 = malloc(sizeof(char *) * 2);
  args4[0] = "echo";
  args4[1] = "-------->";
  args4[2] = NULL;
  char **args5 = malloc(sizeof(char *) * 1);
  args5[0] = "ls";
  args5[1] = NULL;
  char **args6 = malloc(sizeof(char *) * 3);
  args6[0] = "$?";
  args6[1] = "-e";
  args6[1] = NULL;
  p_cmd = listnew("cat", args, 1);
  p_cmd->outfile = NULL;
  p_cmd->infile = malloc(sizeof(char *) * 1);
  p_cmd->infile[0] = malloc(sizeof(char) * 4);
  p_cmd->infile[0] = "f.txt";
  p_cmd->infile[1] = NULL;
  p_cmd->heredoc_del = malloc(sizeof(char *) *1);
  p_cmd->heredoc_del[0] = malloc(sizeof(char) * 2);
  p_cmd->heredoc_del[0] = "z";
  p_cmd->heredoc_del[1] = NULL;
  p_cmd->is_red_or_app = 0;
  //p_cmd->heredoc_del = NULL;
  p_cmd->next = listnew("echo", args2, 1);
  p_cmd->next->next = listnew("cat", args3, 0);
  p_cmd->next->next->next = NULL;

  int fd[2];
  int fd_in = 0;
  int fd_out = 1;
  int out = dup(1);
  int in = dup(0);
  
  while (p_cmd != NULL) {
    //bach nrj3 yktb l output f terminal
    dup2(out, 1);
    dup2(in, 0);
    if(p_cmd->heredoc_del)
      check_heredoc(p_cmd->heredoc_del);

    else if (p_cmd->infile) {
      fd_in = create_in_files(p_cmd);
      dup2(fd_in, 0);
      close(fd_in);
    }
    if (p_cmd->outfile) {
      fd_out = create_out_files(p_cmd);
      dup2(fd_out, 1);
      //bach cat tkhrj 3la l terminal
      dup2(fd_out, 0);
      close(fd_out);
      p_cmd->next->fd_in = 1;
    }
    if (p_cmd->status == 1 && p_cmd->next != NULL && p_cmd->outfile == NULL)
    {
      pipe(fd);
      dup2(fd[1],1);
      close(fd[1]);
       p_cmd->next->fd_in = 1;
    }
    int pid = fork();
    if (pid == 0) {
      if (p_cmd->fd_in != 0){
        dup2(fd[0],0);
        close(fd[0]);
      }
      if(builtin_cmd(p_cmd->command, p_cmd->args))
        exit(0);
      else
      execution(p_cmd->command, p_cmd->args);
    }
     waitpid(pid, &status, 0);
     printf("status = %d\n", status);
    p_cmd = p_cmd->next;
  }
}
