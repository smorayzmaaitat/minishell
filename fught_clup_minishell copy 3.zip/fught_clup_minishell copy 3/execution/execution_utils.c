/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execution_utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: imaaitat <imaaitat@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/17 18:32:05 by imaaitat          #+#    #+#             */
/*   Updated: 2023/05/23 00:53:39 by imaaitat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"
void create_pip(int fd[2], t_cmd *p_cmd) {
  if (pipe(fd) == -1) {
    perror("pipe");
    exit(EXIT_FAILURE);
  }
  dup2(fd[1], 1);
  close(fd[1]);
  if (p_cmd->outfile != NULL || p_cmd->heredoc_del != NULL)
    write(fd[1], " ", 1);
}

void read_pipe(t_cmd *p_cmd, int fd1[2]) {
  if (p_cmd->fd_in != 0 && p_cmd->infile == NULL &&
      p_cmd->heredoc_del == NULL) {
    dup2(fd1[0], 0);
    close(fd1[0]);
  }
}
void execution1(t_env *headd, t_cmd *p_cmd, char **env) {
  int fd2[2];
  int fd1[2];
  int fd_in;
  int fd_out;
  int outfile;
  int fd_heredoc;
  int out = dup(1);
  int in = dup(0);
  while (p_cmd) {
    dup2(out, 1);
    dup2(in, 0);
    if (p_cmd->heredoc_del && fd_heredoc != -1)
      fd_heredoc = check_heredoc(p_cmd->heredoc_del);
      if(fd_heredoc == -1)
              return ;
    if (p_cmd->infile)
      fd_in = create_in_files(p_cmd);
    if (p_cmd->outfile)
    outfile =  create_out_files(p_cmd);
    if (p_cmd->next) {
      if (p_cmd->fd_in == 2) {
         create_pip(fd1, p_cmd);
        p_cmd->next->fd_in = 1;
      } else {
        create_pip(fd2, p_cmd);
        p_cmd->next->fd_in = 2;
      }
    }
    if (builtin_cmd2(p_cmd->command, p_cmd->args, &headd))
      status = 0;
    else {
      int pid = fork();
      if (pid == 0 && fd_heredoc != -1) {
        if (p_cmd->h_i == 1){
          dup2(fd_heredoc, 0);
          close(fd_heredoc);
          
        } else if (p_cmd->h_i == 0) 
        {
          dup2(fd_in, 0);
          close(fd_in);
        }
        if (p_cmd->outfile)
        {
          dup2(outfile, 1);
          close(outfile);
        }
        if (p_cmd->fd_in == 1)
          read_pipe(p_cmd, fd1);
        else if (p_cmd->fd_in == 2)
          read_pipe(p_cmd, fd2);
        if (builtin_cmd(p_cmd->command, p_cmd->args, &headd))
          exit(0);
        else
          execution(p_cmd->command, p_cmd->args, &headd, env);
      }
    }
    waitpid(-1, &status, 0);
    status = WEXITSTATUS(status);
    p_cmd = p_cmd->next;
  }
}